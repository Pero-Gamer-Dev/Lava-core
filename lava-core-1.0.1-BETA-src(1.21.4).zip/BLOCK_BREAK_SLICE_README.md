# Block-break vertical slice — what's real, what's optimized, what's not

## What actually got fixed vs. the original draft

- **Right event, right timing.** `AttackBlockCallback` (initial swing) has been
  replaced with `PlayerBlockBreakEvents.BEFORE`, which fires immediately before
  the block is removed — the same point Bukkit's `BlockBreakEvent` fires at.
- **Real block resolution.** The old code left `bukkitBlock` as `null` with a
  "resolve via world coordinates" comment. `LavaWorldWrapper.getBlockAt(...)`
  now actually does that.
- **Cancellation is wired both ways.** A plugin calling
  `event.setCancelled(true)` now genuinely stops the vanilla break, via the
  `Before` callback's boolean return.

## Optimization pass

1. **World wrapper: hashmap+lock → direct field via Mixin.**
   `LavaWorldWrapper.of(...)` used to look itself up in a `synchronized
   WeakHashMap`. It's now cached directly on the live `ServerLevel` object
   itself (`ServerLevelWorldMixin` + `LavaWorldHolder`), the same pattern
   CraftBukkit/Paper use for entities. That's a direct field read instead of
   a hash + lock on every single block interaction — and it's safe specifically
   *because* Bukkit's contract keeps this access on the main thread, so there
   was never a real concurrency case to protect against.
   - Caveat: this assumption breaks under Folia-style regionized
     multithreading. Flagging it now since "more optimized" and "thread-per-
     region" pull in different directions — worth deciding on purpose later,
     not by accident.

2. **World name/UUID: computed once, not per call.** `getName()`/`getUID()`
   used to rebuild a string and re-hash it on every call. Both never change
   for a Level's lifetime, so they're now computed once in the constructor.

3. **Material mapping: per-call lookup → eager whole-registry cache.**
   `LavaMaterialMapper` used to do a registry-key lookup + string uppercase +
   `Material.matchMaterial` scan on every `getType()` call. It now walks the
   block registry once at class-load into an identity-keyed map (NMS `Block`
   instances are registry singletons, so identity caching is safe), turning
   every later lookup into one hashmap `get`. Bonus: any block that fails to
   auto-map now gets logged once at boot instead of surfacing as a surprise
   exception mid-game the first time a plugin touches an unusual block.

## What I deliberately did *not* "optimize"

- **Block state is re-read on every call, not cached in the wrapper.** This
  looks like duplicate work (`getType()` and `isEmpty()` both hit
  `level.getBlockState(pos)`), but caching it would violate Bukkit's own
  contract: `Block` is documented as a *live view* of world state, while
  `BlockState` is the snapshot type. A plugin holding a `Block` reference
  across ticks is supposed to see current data, not what was true when the
  wrapper was created. If profiling later shows this is actually hot, the
  right fix is a request-scoped cache tied to event dispatch, not caching
  inside the wrapper itself.
- **Event dispatch itself is not async.** The original doc's pitch mentioned
  an "asynchronous... translation layer." Bukkit's plugin API is built on the
  assumption that almost all of it runs synchronously on the main thread —
  most plugins aren't thread-safe and will break (race conditions, concurrent
  modification, silent corruption) if their events fire off-thread. Paper's
  real performance wins come from making things *around* the sync event model
  async (chunk loading, pathfinding, IO) — not from making the event
  dispatch itself concurrent. Doing that here would trade a performance win
  for widespread plugin breakage, which defeats the point of a Bukkit-
  compatibility layer.
- **Object allocation per `getBlockAt()` call is intentional, not a bug.**
  CraftBukkit does the same — `Block` is meant to be a cheap, disposable
  coordinate+world pointer, not something to pool.

## Still-open prerequisites (unchanged from before)

1. A real `org.bukkit.Server` singleton — `LavaCoreInitializer`'s reflection
   hook still grabs `Bukkit.class`'s `server` field and never actually calls
   `.set(...)` on it.
2. Wiring `LavaPlayerWrapper` instances into whatever backs
   `Bukkit.getPlayer()`, so a connecting `ServerPlayer` actually resolves.

Both block this bridge from working against real players, same as before.

## Before you compile

Still no network/build access in this session, so none of this has been run
against real jars. Same caveats as last time apply — especially confirm
`PlayerBlockBreakEvents.Before`'s exact signature against your pinned
fabric-api version, and that `Mixin(ServerLevel.class)` + `@Unique` field
injection matches your Mixin version's expected pattern.
