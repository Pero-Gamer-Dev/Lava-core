/*
 * Copyright (C) 2026 Pero
 * This file is part of Lava-core, licensed under the GNU LGPLv3.
 * See the LICENSE file in the project root for more information.
 */
// ============================================================================
// ============================================================================
package io.github.lavacore.events;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.bukkit.Bukkit;
import org.bukkit.event.block.BlockBreakEvent;
import io.github.lavacore.bridge.world.LavaWorldWrapper;

/**
 * Bridges Fabric's block-break lifecycle to Bukkit's BlockBreakEvent.
 *
 * This replaces the earlier draft's use of AttackBlockCallback, which fires on
 * the *initial* left-click/attack (Bukkit's BlockDamageEvent territory), not on
 * the actual break. PlayerBlockBreakEvents.BEFORE fires right before the block
 * is removed and lets us cancel it — which is the correct timing and
 * cancellation contract to match BlockBreakEvent.
 *
 * NOTE: verify this against your exact fabric-api version's source/javadoc.
 * The Before functional interface's parameter types/order have to match
 * exactly for the method reference below to compile — if your IDE flags a
 * mismatch, that error will show you the real signature to adjust to. I don't
 * have a live build to confirm this against in this session.
 */
public final class LavaBlockBridge {

    private LavaBlockBridge() {}

    public static void registerEventBuses() {
        PlayerBlockBreakEvents.BEFORE.register(LavaBlockBridge::onBeforeBlockBreak);
    }

    private static boolean onBeforeBlockBreak(Level level, Player player, BlockPos pos,
                                               BlockState state, BlockEntity blockEntity) {
        // Fabric fires this for any Player, but Bukkit only knows about
        // connected server players tracked through the (still-to-be-built)
        // Bukkit Server singleton / entity bridge.
        org.bukkit.entity.Player bukkitPlayer = Bukkit.getPlayer(player.getUUID());
        if (bukkitPlayer == null) {
            return true; // not a tracked Bukkit player — let vanilla handle it untouched
        }

        org.bukkit.block.Block bukkitBlock = LavaWorldWrapper.of(level)
                .getBlockAt(pos.getX(), pos.getY(), pos.getZ());

        BlockBreakEvent bukkitEvent = new BlockBreakEvent(bukkitBlock, bukkitPlayer);
        Bukkit.getPluginManager().callEvent(bukkitEvent);

        // Fabric's contract for a "Before" boolean event: false cancels the action.
        return !bukkitEvent.isCancelled();
    }
}
