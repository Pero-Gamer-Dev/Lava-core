/*
 * Copyright (C) 2026 Pero
 * This file is part of Lava-core, licensed under the GNU LGPLv3.
 * See the LICENSE file in the project root for more information.
 */
package io.github.lavacore.scheduler;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
public final class LavaScheduler implements BukkitScheduler {
    private final AtomicInteger ids = new AtomicInteger(1);
    private final ConcurrentHashMap<Integer,LavaTask> tasks = new ConcurrentHashMap<>();
    private final Executor async = Executors.newCachedThreadPool(r -> { Thread t=new Thread(r,"lava-async"); t.setDaemon(true); return t; });
    private long currentTick=0;
    public void pulse() {
        currentTick++;
        List<LavaTask> due=new ArrayList<>();
        for (LavaTask t: tasks.values()) {
            if (t.cancelled) { tasks.remove(t.id); continue; }
            if (t.nextTick<=currentTick) due.add(t);
        }
        for (LavaTask t: due) {
            if (t.period<0) tasks.remove(t.id); else t.nextTick=currentTick+Math.max(1,t.period);
            try { if (t.sync) t.run(); else async.execute(t); }
            catch (Throwable ex) { ex.printStackTrace(); }
        }
    }
    private BukkitTask sched(Plugin p, Runnable r, boolean sync, long delay, long period) {
        int id=ids.getAndIncrement();
        LavaTask t=new LavaTask(id,p,sync,r,currentTick+Math.max(0,delay),period);
        tasks.put(id,t); return t;
    }
    @Override public int scheduleSyncDelayedTask(Plugin p, Runnable t, long d){return sched(p,t,true,d,-1).getTaskId();}
    @Override public int scheduleSyncDelayedTask(Plugin p, BukkitRunnable t, long d){return scheduleSyncDelayedTask(p,(Runnable)t,d);}
    @Override public int scheduleSyncDelayedTask(Plugin p, Runnable t){return scheduleSyncDelayedTask(p,t,0);}
    @Override public int scheduleSyncDelayedTask(Plugin p, BukkitRunnable t){return scheduleSyncDelayedTask(p,(Runnable)t,0);}
    @Override public int scheduleSyncRepeatingTask(Plugin p, Runnable t, long d, long per){return sched(p,t,true,d,per).getTaskId();}
    @Override public int scheduleSyncRepeatingTask(Plugin p, BukkitRunnable t, long d, long per){return scheduleSyncRepeatingTask(p,(Runnable)t,d,per);}
    @Override public int scheduleAsyncDelayedTask(Plugin p, Runnable t, long d){return sched(p,t,false,d,-1).getTaskId();}
    @Override public int scheduleAsyncDelayedTask(Plugin p, Runnable t){return scheduleAsyncDelayedTask(p,t,0);}
    @Override public int scheduleAsyncRepeatingTask(Plugin p, Runnable t, long d, long per){return sched(p,t,false,d,per).getTaskId();}
    @Override public <T> Future<T> callSyncMethod(Plugin p, Callable<T> c){ FutureTask<T> f=new FutureTask<>(c); runTask(p,f); return f; }
    @Override public void cancelTask(int id){ LavaTask t=tasks.remove(id); if(t!=null) t.cancel(); }
    @Override public void cancelTasks(Plugin p){ tasks.values().removeIf(t -> { if(t.owner==p){ t.cancel(); return true;} return false; }); }
    @Override public boolean isCurrentlyRunning(int id){return false;}
    @Override public boolean isQueued(int id){return tasks.containsKey(id);}
    @Override public List<BukkitWorker> getActiveWorkers(){return List.of();}
    @Override public List<BukkitTask> getPendingTasks(){return new ArrayList<>(tasks.values());}
    @Override public BukkitTask runTask(Plugin p, Runnable t){return sched(p,t,true,0,-1);}
    @Override public void runTask(Plugin p, Consumer<? super BukkitTask> t){ t.accept(sched(p,()->{},true,0,-1)); }
    @Override public BukkitTask runTask(Plugin p, BukkitRunnable t){return runTask(p,(Runnable)t);}
    @Override public BukkitTask runTaskAsynchronously(Plugin p, Runnable t){return sched(p,t,false,0,-1);}
    @Override public void runTaskAsynchronously(Plugin p, Consumer<? super BukkitTask> t){ t.accept(sched(p,()->{},false,0,-1)); }
    @Override public BukkitTask runTaskAsynchronously(Plugin p, BukkitRunnable t){return runTaskAsynchronously(p,(Runnable)t);}
    @Override public BukkitTask runTaskLater(Plugin p, Runnable t, long d){return sched(p,t,true,d,-1);}
    @Override public void runTaskLater(Plugin p, Consumer<? super BukkitTask> t, long d){ t.accept(sched(p,()->{},true,d,-1)); }
    @Override public BukkitTask runTaskLater(Plugin p, BukkitRunnable t, long d){return runTaskLater(p,(Runnable)t,d);}
    @Override public BukkitTask runTaskLaterAsynchronously(Plugin p, Runnable t, long d){return sched(p,t,false,d,-1);}
    @Override public void runTaskLaterAsynchronously(Plugin p, Consumer<? super BukkitTask> t, long d){ t.accept(sched(p,()->{},false,d,-1)); }
    @Override public BukkitTask runTaskLaterAsynchronously(Plugin p, BukkitRunnable t, long d){return runTaskLaterAsynchronously(p,(Runnable)t,d);}
    @Override public BukkitTask runTaskTimer(Plugin p, Runnable t, long d, long per){return sched(p,t,true,d,per);}
    @Override public void runTaskTimer(Plugin p, Consumer<? super BukkitTask> t, long d, long per){ t.accept(sched(p,()->{},true,d,per)); }
    @Override public BukkitTask runTaskTimer(Plugin p, BukkitRunnable t, long d, long per){return runTaskTimer(p,(Runnable)t,d,per);}
    @Override public BukkitTask runTaskTimerAsynchronously(Plugin p, Runnable t, long d, long per){return sched(p,t,false,d,per);}
    @Override public void runTaskTimerAsynchronously(Plugin p, Consumer<? super BukkitTask> t, long d, long per){ t.accept(sched(p,()->{},false,d,per)); }
    @Override public BukkitTask runTaskTimerAsynchronously(Plugin p, BukkitRunnable t, long d, long per){return runTaskTimerAsynchronously(p,(Runnable)t,d,per);}
    @Override public Executor getMainThreadExecutor(Plugin p){ return r -> sched(p,r,true,0,-1); }
}
