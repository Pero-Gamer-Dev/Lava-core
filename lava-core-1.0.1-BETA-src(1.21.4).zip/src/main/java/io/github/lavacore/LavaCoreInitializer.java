/*
 * Copyright (C) 2026 Pero
 * This file is part of Lava-core, licensed under the GNU LGPLv3.
 * See the LICENSE file in the project root for more information.
 */
package io.github.lavacore;

import net.fabricmc.api.DedicatedServerModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.minecraft.server.dedicated.DedicatedServer;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.plugin.Plugin;
import io.github.lavacore.bridge.LavaServer;
import io.github.lavacore.bridge.entity.LavaPlayerWrapper;
import io.github.lavacore.events.LavaBlockBridge;

import java.io.File;
import java.util.HashSet;
import java.util.concurrent.atomic.AtomicBoolean;

public class LavaCoreInitializer implements DedicatedServerModInitializer {
    private static final AtomicBoolean BOUND = new AtomicBoolean(false);

    @Override
    public void onInitializeServer() {
        System.out.println("[Lava] 1.0.1-BETA bootstrapping (MC 1.21.4 plugin bridge)...");
        new File("plugins").mkdirs();
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            if (server instanceof DedicatedServer dedicated) initializeLavaEngine(dedicated);
        });
        ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((message, sender, params) -> {
            LavaServer lava = LavaServer.getInstance();
            if (lava == null) return true;
            LavaPlayerWrapper player = (LavaPlayerWrapper) lava.getPlayer(sender.getUUID());
            if (player == null) return true;
            String plain = message.decoratedContent().getString();
            AsyncPlayerChatEvent event = new AsyncPlayerChatEvent(false, player, plain, new HashSet<>(lava.getOnlinePlayers()));
            lava.getPluginManager().callEvent(event);
            return !event.isCancelled();
        });
    }

    public static void initializeLavaEngine(DedicatedServer dedicatedServerInstance) {
        if (!BOUND.compareAndSet(false, true)) return;
        try {
            System.out.println("[Lava] Binding Bukkit API to Fabric context...");
            LavaServer server = LavaServer.bind(dedicatedServerInstance);
            LavaBlockBridge.registerEventBuses();
            File pluginFolder = server.getPluginsFolder();
            pluginFolder.mkdirs();
            Plugin[] loaded = server.getPluginManager().loadPlugins(pluginFolder);
            for (Plugin plugin : loaded) {
                try {
                    server.getPluginManager().enablePlugin(plugin);
                    System.out.println("[Lava] Enabled plugin " + plugin.getName());
                } catch (Exception e) {
                    System.err.println("[Lava] Failed to enable plugin " + plugin.getName());
                    e.printStackTrace();
                }
            }
            System.out.println("[Lava] System linked. Plugin pipeline ready (" + loaded.length + " plugin(s)).");
        } catch (Exception ex) {
            BOUND.set(false);
            System.err.println("[Lava] Failed to bind Bukkit singleton!");
            ex.printStackTrace();
        }
    }
}
