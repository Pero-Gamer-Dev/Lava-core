/*
 * Copyright (C) 2026 Pero
 * This file is part of Lava-core, licensed under the GNU LGPLv3.
 * See the LICENSE file in the project root for more information.
 */
package io.github.lavacore.plugin;
import io.papermc.paper.plugin.configuration.PluginMeta;
import io.papermc.paper.plugin.provider.classloader.*;
import org.bukkit.plugin.*;
import org.bukkit.plugin.java.JavaPlugin;
import io.github.lavacore.bridge.LavaServer;
import io.github.lavacore.loader.LavaClassRemapper;
import java.io.*;
import java.net.*;
import java.util.jar.*;
import java.util.logging.Logger;
public final class LavaPluginClassLoader extends URLClassLoader implements ConfiguredPluginClassLoader {
    static { ClassLoader.registerAsParallelCapable(); }
    private final PluginDescriptionFile description;
    private final File dataFolder, file;
    private final JarFile jar;
    private JavaPlugin plugin;
    public LavaPluginClassLoader(ClassLoader parent, PluginDescriptionFile description, File dataFolder, File file)
            throws IOException, InvalidPluginException {
        super(file.getName(), new URL[]{file.toURI().toURL()}, parent);
        this.description = description; this.dataFolder = dataFolder; this.file = file;
        this.jar = new JarFile(file);
        LavaPluginClassLoaderGroup.GLOBAL.add(this);
        try {
            Class<?> jarClass = Class.forName(description.getMain(), true, this);
            this.plugin = jarClass.asSubclass(JavaPlugin.class).getDeclaredConstructor().newInstance();
        } catch (ClassNotFoundException e) { throw new InvalidPluginException("Cannot find main class `" + description.getMain() + "'", e); }
        catch (ClassCastException e) { throw new InvalidPluginException("main class must extend JavaPlugin", e); }
        catch (Exception e) { throw new InvalidPluginException("Exception initializing " + description.getMain(), e); }
    }
    @Override public PluginMeta getConfiguration() { return description; }
    @Override public Class<?> loadClass(String name, boolean resolve, boolean checkGlobal, boolean checkLibraries) throws ClassNotFoundException {
        try { return super.loadClass(name, resolve); }
        catch (ClassNotFoundException ex) {
            if (checkGlobal) {
                Class<?> f = LavaPluginClassLoaderGroup.GLOBAL.getClassByName(name, resolve, this);
                if (f != null) return f;
            }
            throw ex;
        }
    }
    @Override protected Class<?> findClass(String name) throws ClassNotFoundException {
        JarEntry entry = jar.getJarEntry(name.replace('.','/') + ".class");
        if (entry == null) return super.findClass(name);
        try (InputStream in = jar.getInputStream(entry)) {
            byte[] bytes = LavaClassRemapper.remap(in.readAllBytes());
            return defineClass(name, bytes, 0, bytes.length);
        } catch (IOException e) { throw new ClassNotFoundException(name, e); }
    }
    @Override public void init(JavaPlugin plugin) {
        plugin.init(LavaServer.getInstance(), description, dataFolder, file, this, description, Logger.getLogger(description.getName()));
        this.plugin = plugin;
    }
    @Override public JavaPlugin getPlugin() { return plugin; }
    @Override public PluginClassLoaderGroup getGroup() { return LavaPluginClassLoaderGroup.GLOBAL; }
    @Override public void close() throws IOException {
        LavaPluginClassLoaderGroup.GLOBAL.remove(this);
        try { super.close(); } finally { jar.close(); }
    }
}
