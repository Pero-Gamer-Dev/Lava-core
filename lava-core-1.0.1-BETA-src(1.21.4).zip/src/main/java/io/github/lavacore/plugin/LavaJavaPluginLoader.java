/*
 * Copyright (C) 2026 Pero
 * This file is part of Lava-core, licensed under the GNU LGPLv3.
 * See the LICENSE file in the project root for more information.
 */
package io.github.lavacore.plugin;
import org.bukkit.Server;
import org.bukkit.event.*;
import org.bukkit.plugin.*;
import org.bukkit.plugin.java.*;
import io.github.lavacore.bridge.LavaServer;
import java.io.*;
import java.util.*;
import java.util.jar.*;
import java.util.regex.Pattern;
public final class LavaJavaPluginLoader implements PluginLoader {
    private final Server server;
    private final JavaPluginLoader listenerFactory;
    public LavaJavaPluginLoader() {
        this.server = LavaServer.getInstance();
        this.listenerFactory = server == null ? null : new JavaPluginLoader(server);
    }
    public LavaJavaPluginLoader(Server server) {
        this.server = server;
        this.listenerFactory = new JavaPluginLoader(server);
    }
    @Override public Plugin loadPlugin(File file) throws InvalidPluginException, UnknownDependencyException {
        if (file == null || !file.exists()) throw new InvalidPluginException("missing " + file);
        PluginDescriptionFile description;
        try { description = getPluginDescription(file); }
        catch (InvalidDescriptionException ex) { throw new InvalidPluginException(ex); }
        File dataFolder = new File(server.getPluginsFolder(), description.getName());
        try {
            return new LavaPluginClassLoader(JavaPlugin.class.getClassLoader(), description, dataFolder, file).getPlugin();
        } catch (InvalidPluginException e) { throw e; }
        catch (Exception e) { throw new InvalidPluginException(e); }
    }
    @Override public PluginDescriptionFile getPluginDescription(File file) throws InvalidDescriptionException {
        try (JarFile jar = new JarFile(file)) {
            JarEntry entry = jar.getJarEntry("plugin.yml");
            if (entry == null) entry = jar.getJarEntry("paper-plugin.yml");
            if (entry == null) throw new InvalidDescriptionException("No plugin.yml in " + file.getName());
            try (InputStream in = jar.getInputStream(entry)) { return new PluginDescriptionFile(in); }
        } catch (InvalidDescriptionException e) { throw e; }
        catch (Exception e) { throw new InvalidDescriptionException(e); }
    }
    @Override public Pattern[] getPluginFileFilters() { return new Pattern[]{Pattern.compile("\\.jar$")}; }
    @Override public Map<Class<? extends Event>, Set<RegisteredListener>> createRegisteredListeners(Listener listener, Plugin plugin) {
        return listenerFactory.createRegisteredListeners(listener, plugin);
    }
    @Override public void enablePlugin(Plugin plugin) {
        if (plugin instanceof JavaPlugin jp && !plugin.isEnabled()) {
            plugin.getLogger().info("Enabling " + plugin.getDescription().getFullName());
            jp.setEnabled(true);
        }
    }
    @Override public void disablePlugin(Plugin plugin) {
        if (plugin instanceof JavaPlugin jp && plugin.isEnabled()) {
            plugin.getLogger().info("Disabling " + plugin.getDescription().getFullName());
            jp.setEnabled(false);
        }
    }
}
