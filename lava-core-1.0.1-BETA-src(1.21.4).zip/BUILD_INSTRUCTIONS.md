# Lava-core build instructions (1.0.1-BETA)

## Prerequisites

- **JDK 21**
- Network on first build (Mojang jars, Fabric Loom, Paper API)
- Gradle wrapper included (`./gradlew`)

## Build

```bash
cd lava-core
./gradlew remapJar
```

Remapped mod:

```
build/libs/lava-core-1.0.1-BETA.jar
```

## Versions pinned here

| Piece         | Version                |
|---------------|------------------------|
| Minecraft     | **1.21.4**             |
| Mappings      | official Mojang        |
| Fabric Loom   | 1.8.4                  |
| Fabric Loader | 0.16.9                 |
| Fabric API    | 0.119.2+1.21.4         |
| Paper API     | 1.21.4-R0.1-SNAPSHOT   |
| Java          | 21                     |
| License       | GNU LGPLv3             |
| Package       | `io.github.lavacore`   |

## Run

Use an official Fabric **server** installer for **1.21.4**, drop the jar in `mods/`, create `plugins/` for Bukkit jars, start the server.
