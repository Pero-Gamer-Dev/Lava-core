# Lava-core 1.0.3-BETA

Fabric dedicated-server hybrid that loads **Bukkit/Paper Java plugins** on Minecraft **1.21.4**.

Copyright (C) 2026 Pero — licensed under the **GNU LGPLv3** (see `LICENSE`).

Package root: `io.github.lavacore`

## Install

1. Fabric dedicated server for **Minecraft 1.21.4** (loader 0.16.9+).
2. Drop `lava-core-1.0.3-BETA.jar` into `mods/`.
3. Drop Paper/Spigot plugins (EssentialsX, Vault, LuckPerms, …) into `plugins/`.
4. Start the server. Look for `[Lava] System linked`.

This jar will **not** load on 1.21.1 (`depends: minecraft ~1.21.4`).

## What works in 1.0.1

- Real Java plugin classloader (`ConfiguredPluginClassLoader`) — Paper’s own `JavaPluginLoader.loadPlugin()` throws on 1.21.4
- `plugin.yml` parse, dependency order, permissions, command registration
- Scheduler (sync + async), ServicesManager (Vault), Messenger, UnsafeValues
- Player join/quit/chat/command events
- Live player: name, uuid, world, location, teleport, sendMessage, gamemode, health, food, op, kick, performCommand, permissions
- CraftBukkit aliases (`CraftServer` / `CraftPlayer` + remaps of `v1_20_R*` / `v1_21_R*`)
- Block-break bridge (Fabric → Bukkit `BlockBreakEvent`)

## ViaVersion

Use **ViaFabric** (Fabric mod) for protocol translation. The Bukkit ViaVersion jar talks to Spigot NMS and will not work as a `plugins/` jar on Lava.

## EssentialsX

Place `EssentialsX` + `Vault` (and optionally LuckPerms) in `plugins/`. Homes/warps/kits that only need Bukkit commands, scheduler, and teleport should enable. Features that poke NMS may still no-op.

## Build

```bash
cd lava-core
./gradlew remapJar
# output: build/libs/lava-core-1.0.3-BETA.jar
```

Requires **JDK 21** and network on first run (Mojang, Fabric Loom, Paper API).

## Versions

| Piece         | Version                |
|---------------|------------------------|
| Minecraft     | **1.21.4**             |
| Mappings      | official Mojang        |
| Fabric Loom   | 1.8.4                  |
| Fabric Loader | 0.16.9                 |
| Fabric API    | 0.119.2+1.21.4         |
| Paper API     | 1.21.4-R0.1-SNAPSHOT   |
| Java          | 21                     |
| Group/package | `io.github.lavacore`   |
